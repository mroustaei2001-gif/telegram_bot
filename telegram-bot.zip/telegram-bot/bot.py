import os
import json
import logging
import asyncio
from threading import Thread
from flask import Flask
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.enums import ChatAction
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.exceptions import TelegramBadRequest

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = os.getenv("ADMIN_ID")

if not all([BOT_TOKEN, ADMIN_ID]):
    raise ValueError("BOT_TOKEN and ADMIN_ID must be set!")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# ========== Flask برای بیدار نگه داشتن ربات ==========
app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running! ✅"

def run_flask():
    app.run(host='0.0.0.0', port=5000)

# ========== فایل‌های ذخیره‌سازی ==========
TOPIC_FILE = "daily_topic.txt"
SENT_USERS_FILE = "sent_users.json"
SETTINGS_FILE = "settings.json"

def save_topic(topic):
    with open(TOPIC_FILE, "w", encoding="utf-8") as f:
        f.write(topic)

def load_topic():
    try:
        with open(TOPIC_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except:
        return "موضوعی ثبت نشده"

def load_sent_users():
    try:
        with open(SENT_USERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return []

def save_sent_users(users):
    with open(SENT_USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f)

def clear_sent_users():
    save_sent_users([])

def has_user_sent(user_id):
    users = load_sent_users()
    return str(user_id) in users

def add_user_to_sent(user_id):
    users = load_sent_users()
    users.append(str(user_id))
    save_sent_users(users)

def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {
            "force_join": True,
            "promo_channels": [],
            "show_promo": True,
            "channel_id": os.getenv("CHANNEL_ID", ""),
            "channel_link": os.getenv("CHANNEL_LINK", "")
        }

def save_settings(settings):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)

def get_channel_id():
    settings = load_settings()
    return settings.get("channel_id", os.getenv("CHANNEL_ID", ""))

def get_channel_link():
    settings = load_settings()
    return settings.get("channel_link", os.getenv("CHANNEL_LINK", ""))

def set_channel(channel_id, channel_link):
    settings = load_settings()
    settings["channel_id"] = channel_id
    settings["channel_link"] = channel_link
    save_settings(settings)

def is_force_join_enabled():
    settings = load_settings()
    return settings.get("force_join", True)

def toggle_force_join():
    settings = load_settings()
    current = settings.get("force_join", True)
    settings["force_join"] = not current
    save_settings(settings)
    return not current

def get_promo_channels():
    settings = load_settings()
    return settings.get("promo_channels", [])

def add_promo_channel(name, link):
    settings = load_settings()
    if "promo_channels" not in settings:
        settings["promo_channels"] = []
    settings["promo_channels"].append({"name": name, "link": link})
    save_settings(settings)

def remove_promo_channel(index):
    settings = load_settings()
    if "promo_channels" in settings and 0 <= index < len(settings["promo_channels"]):
        settings["promo_channels"].pop(index)
        save_settings(settings)
        return True
    return False

def is_promo_enabled():
    settings = load_settings()
    return settings.get("show_promo", True)

def toggle_promo():
    settings = load_settings()
    current = settings.get("show_promo", True)
    settings["show_promo"] = not current
    save_settings(settings)
    return not current

class UserState(StatesGroup):
    waiting_anonymous = State()
    waiting_identified = State()
    adding_promo_name = State()
    adding_promo_link = State()
    changing_channel_id = State()
    changing_channel_link = State()

def join_channel_keyboard():
    channel_link = get_channel_link()
    buttons = [
        [InlineKeyboardButton(text="\U0001F4E2 عضویت در کانال", url=channel_link)]
    ]
    if is_promo_enabled():
        promo_channels = get_promo_channels()
        for channel in promo_channels:
            buttons.append([InlineKeyboardButton(text=f"\U0001F4E3 {channel['name']}", url=channel['link'])])
    buttons.append([InlineKeyboardButton(text="\u2705 عضو شدم، بررسی کن", callback_data="check_join")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def main_menu_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="\U0001F4F0 موضوع روز", callback_data="daily_topic")],
        [InlineKeyboardButton(text="\U0001F4E9 پیام ناشناس", callback_data="send_anon")],
        [InlineKeyboardButton(text="\U0001F464 پیام با هویت", callback_data="send_id")],
        [InlineKeyboardButton(text="\U0001F4DC قوانین", callback_data="rules")],
    ])

def admin_panel_keyboard():
    force_status = "\u2705 فعال" if is_force_join_enabled() else "\u274C غیرفعال"
    promo_status = "\u2705 نمایش" if is_promo_enabled() else "\u274C مخفی"
    promo_count = len(get_promo_channels())
    channel_id = get_channel_id()
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"\U0001F512 عضویت اجباری: {force_status}", callback_data="toggle_force_join")],
        [InlineKeyboardButton(text=f"\U0001F4E3 تبلیغات ({promo_count}): {promo_status}", callback_data="promo_settings")],
        [InlineKeyboardButton(text=f"\U0001F4C2 کانال: {channel_id[:15]}...", callback_data="change_channel")],
        [InlineKeyboardButton(text="\U0001F519 بازگشت به منو", callback_data="back_menu")]
    ])

def promo_settings_keyboard():
    promo_channels = get_promo_channels()
    buttons = []
    for i, channel in enumerate(promo_channels):
        buttons.append([
            InlineKeyboardButton(text=f"\U0001F4DD {channel['name']}", callback_data=f"view_promo_{i}"),
            InlineKeyboardButton(text="\U0001F5D1\ufe0f حذف", callback_data=f"delete_promo_{i}")
        ])
    buttons.append([InlineKeyboardButton(text="\u2795 افزودن کانال جدید", callback_data="add_promo")])
    promo_status = "\u2705 نمایش" if is_promo_enabled() else "\u274C مخفی"
    buttons.append([InlineKeyboardButton(text=f"\U0001F515 تغییر وضعیت: {promo_status}", callback_data="toggle_promo")])
    buttons.append([InlineKeyboardButton(text="\U0001F519 بازگشت", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def main_menu_with_admin_keyboard():
    keyboard = [
        [InlineKeyboardButton(text="\U0001F4F0 موضوع روز", callback_data="daily_topic")],
        [InlineKeyboardButton(text="\U0001F4E9 پیام ناشناس", callback_data="send_anon")],
        [InlineKeyboardButton(text="\U0001F464 پیام با هویت", callback_data="send_id")],
        [InlineKeyboardButton(text="\U0001F4DC قوانین", callback_data="rules")],
    ]
    keyboard.append([InlineKeyboardButton(text="\u2699\ufe0f پنل مدیریت", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def back_to_menu_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="\U0001F519 بازگشت به منو", callback_data="back_menu")]
    ])

@dp.message(CommandStart())
async def cmd_start(message: Message):
    user_id = message.from_user.id
    channel_id = get_channel_id()
    if is_force_join_enabled() and channel_id:
        try:
            member = await bot.get_chat_member(channel_id, user_id)
            if member.status not in ["member", "administrator", "creator"]:
                await message.answer("\u26A0\ufe0F برای استفاده از ربات، ابتدا باید در کانال عضو بشی.", reply_markup=join_channel_keyboard())
                return
        except TelegramBadRequest:
            await message.answer("\u26A0\ufe0F برای استفاده از ربات، ابتدا باید در کانال عضو بشی.", reply_markup=join_channel_keyboard())
            return
    await message.answer("\U0001F44B خوش آمدید به کانال خودتون\u2764\ufe0F\nمارو به دوستاتون معرفی کنید!")
    topic = load_topic()
    await message.answer(f"\U0001F4F0 موضوع روز کانال:\n\n\u2728 {topic}")
    if str(user_id) == ADMIN_ID:
        await message.answer("از منوی زیر یکی رو انتخاب کن:", reply_markup=main_menu_with_admin_keyboard())
    else:
        await message.answer("از منوی زیر یکی رو انتخاب کن:", reply_markup=main_menu_keyboard())

@dp.callback_query(F.data == "check_join")
async def check_join(callback: CallbackQuery):
    channel_id = get_channel_id()
    if not is_force_join_enabled():
        await callback.message.edit_text("\u2705 عضویت اجباری غیرفعال است!")
        topic = load_topic()
        await callback.message.answer(f"\U0001F4F0 موضوع روز کانال:\n\n\u2728 {topic}")
        await callback.message.answer("از منوی زیر یکی رو انتخاب کن:", reply_markup=main_menu_keyboard())
        return
    try:
        member = await bot.get_chat_member(channel_id, callback.from_user.id)
        if member.status in ["member", "administrator", "creator"]:
            await callback.message.edit_text("\u2705 عضویت تایید شد!")
            topic = load_topic()
            await callback.message.answer(f"\U0001F4F0 موضوع روز کانال:\n\n\u2728 {topic}")
            await callback.message.answer("از منوی زیر یکی رو انتخاب کن:", reply_markup=main_menu_keyboard())
        else:
            await callback.answer("\u274C هنوز عضو نشدی!", show_alert=True)
    except:
        await callback.answer("\u274C هنوز عضو کانال نیستی!", show_alert=True)

@dp.callback_query(F.data == "daily_topic")
async def show_daily_topic(callback: CallbackQuery):
    topic = load_topic()
    await callback.message.edit_text(f"\U0001F4F0 موضوع روز کانال:\n\n\u2728 {topic}\n\nمی‌تونید در مورد این موضوع پیام ارسال کنید.", reply_markup=back_to_menu_keyboard())

@dp.callback_query(F.data == "admin_panel")
async def admin_panel(callback: CallbackQuery):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    force_status = "\u2705 فعال" if is_force_join_enabled() else "\u274C غیرفعال"
    promo_status = "\u2705 نمایش" if is_promo_enabled() else "\u274C مخفی"
    promo_count = len(get_promo_channels())
    channel_id = get_channel_id()
    channel_link = get_channel_link()
    await callback.message.edit_text(f"\u2699\ufe0F پنل مدیریت\n\n\U0001F512 عضویت اجباری: {force_status}\n\U0001F4E3 تبلیغات: {promo_count}\n\U0001F515 نمایش تبلیغات: {promo_status}\n\U0001F4C2 کانال: {channel_id}\n\U0001F517 لینک: {channel_link}", reply_markup=admin_panel_keyboard())

@dp.callback_query(F.data == "toggle_force_join")
async def toggle_force_join_handler(callback: CallbackQuery):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    new_status = toggle_force_join()
    status_text = "\u2705 فعال" if new_status else "\u274C غیرفعال"
    await callback.message.edit_text(f"\u2705 عضویت اجباری {status_text} شد!", reply_markup=admin_panel_keyboard())

@dp.callback_query(F.data == "change_channel")
async def change_channel_start(callback: CallbackQuery, state: FSMContext):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    current_id = get_channel_id()
    current_link = get_channel_link()
    await state.set_state(UserState.changing_channel_id)
    await callback.message.edit_text(f"\U0001F4C2 تغییر کانال مبدا\n\nکانال فعلی: {current_id}\nلینک فعلی: {current_link}\n\nلطفاً آیدی عددی کانال جدید رو وارد کنید:\n(مثال: -1001234567890)")

@dp.message(UserState.changing_channel_id)
async def change_channel_id(message: Message, state: FSMContext):
    if not message.text:
        return
    channel_id = message.text.strip()
    await state.update_data(channel_id=channel_id)
    await state.set_state(UserState.changing_channel_link)
    await message.answer("حالا لینک کانال جدید رو وارد کنید:\nمثال: https://t.me/channelname")

@dp.message(UserState.changing_channel_link)
async def change_channel_link(message: Message, state: FSMContext):
    if not message.text:
        return
    data = await state.get_data()
    channel_id = data.get("channel_id")
    channel_link = message.text.strip()
    if not channel_link.startswith("https://t.me/"):
        await message.answer("\u274C لینک نامعتبر است! باید با https://t.me/ شروع بشه.")
        return
    set_channel(channel_id, channel_link)
    await message.answer(f"\u2705 کانال مبدا تغییر کرد!\nآیدی: {channel_id}\nلینک: {channel_link}", reply_markup=admin_panel_keyboard())
    await state.clear()

@dp.callback_query(F.data == "promo_settings")
async def promo_settings(callback: CallbackQuery):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    promo_channels = get_promo_channels()
    promo_status = "\u2705 نمایش" if is_promo_enabled() else "\u274C مخفی"
    text = f"\U0001F4E3 مدیریت تبلیغات\n\nوضعیت: {promo_status}\n\n"
    if promo_channels:
        for i, channel in enumerate(promo_channels, 1):
            text += f"{i}. {channel['name']}\n   {channel['link']}\n\n"
    else:
        text += "هیچ کانالی اضافه نشده!\n\n"
    await callback.message.edit_text(text, reply_markup=promo_settings_keyboard())

@dp.callback_query(F.data == "toggle_promo")
async def toggle_promo_handler(callback: CallbackQuery):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    new_status = toggle_promo()
    status_text = "\u2705 نمایش" if new_status else "\u274C مخفی"
    await callback.message.edit_text(f"وضعیت نمایش تبلیغات {status_text} شد!", reply_markup=promo_settings_keyboard())

@dp.callback_query(F.data.startswith("delete_promo_"))
async def delete_promo_handler(callback: CallbackQuery):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    index = int(callback.data.split("_")[-1])
    promo_channels = get_promo_channels()
    if 0 <= index < len(promo_channels):
        channel_name = promo_channels[index]['name']
        remove_promo_channel(index)
        await callback.message.edit_text(f"\U0001F5D1\ufe0F کانال حذف شد: {channel_name}", reply_markup=promo_settings_keyboard())

@dp.callback_query(F.data == "add_promo")
async def add_promo_start(callback: CallbackQuery, state: FSMContext):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    await state.set_state(UserState.adding_promo_name)
    await callback.message.edit_text("نام کانال تبلیغاتی رو وارد کنید:")

@dp.message(UserState.adding_promo_name)
async def add_promo_name(message: Message, state: FSMContext):
    if not message.text:
        return
    await state.update_data(promo_name=message.text)
    await state.set_state(UserState.adding_promo_link)
    await message.answer("لینک کانال رو وارد کنید:\nمثال: https://t.me/channelname")

@dp.message(UserState.adding_promo_link)
async def add_promo_link(message: Message, state: FSMContext):
    if not message.text:
        return
    data = await state.get_data()
    name = data.get("promo_name")
    link = message.text
    if not link.startswith("https://t.me/"):
        await message.answer("\u274C لینک نامعتبر است!")
        return
    add_promo_channel(name, link)
    await message.answer(f"\u2705 کانال اضافه شد!\nنام: {name}\nلینک: {link}", reply_markup=promo_settings_keyboard())
    await state.clear()

@dp.callback_query(F.data.startswith("view_promo_"))
async def view_promo_handler(callback: CallbackQuery):
    if str(callback.from_user.id) != ADMIN_ID:
        await callback.answer("\u274C دسترسی ندارید!", show_alert=True)
        return
    index = int(callback.data.split("_")[-1])
    promo_channels = get_promo_channels()
    if 0 <= index < len(promo_channels):
        channel = promo_channels[index]
        await callback.message.edit_text(f"نام: {channel['name']}\nلینک: {channel['link']}", reply_markup=promo_settings_keyboard())

@dp.callback_query(F.data == "send_anon")
async def start_anonymous(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    channel_id = get_channel_id()
    if is_force_join_enabled() and channel_id:
        try:
            member = await bot.get_chat_member(channel_id, user_id)
            if member.status not in ["member", "administrator", "creator"]:
                await callback.message.edit_text("\u26A0\ufe0F باید در کانال عضو باشی.", reply_markup=join_channel_keyboard())
                return
        except:
            await callback.message.edit_text("\u26A0\ufe0F باید در کانال عضو باشی.", reply_markup=join_channel_keyboard())
            return
    if has_user_sent(user_id):
        await callback.message.edit_text("\u26A0\ufe0F شما در طول روز یک بار می‌توانید پیام ارسال کنید!", reply_markup=back_to_menu_keyboard())
        return
    topic = load_topic()
    await state.set_state(UserState.waiting_anonymous)
    await callback.message.edit_text(f"\U0001F4F0 موضوع امروز: {topic}\n\n\U0001F4E9 پیام ناشناس\n\nپیام متنی خودتون رو ارسال کنید\nاین پیام بدون یوزرنیم شما فوروارد می‌شه\U0001F64F\n\n\U0001F6E1\ufe0F توجه : پیام خودتون رو به صورت کامل و بدون کات یک جا بفرستید .\U0001FAE0\U0001F64F\n\n\u26A0\ufe0F برای انصراف دکمه پایین رو بزن.", reply_markup=back_to_menu_keyboard())

@dp.callback_query(F.data == "send_id")
async def start_identified(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    channel_id = get_channel_id()
    if is_force_join_enabled() and channel_id:
        try:
            member = await bot.get_chat_member(channel_id, user_id)
            if member.status not in ["member", "administrator", "creator"]:
                await callback.message.edit_text("\u26A0\ufe0F باید در کانال عضو باشی.", reply_markup=join_channel_keyboard())
                return
        except:
            await callback.message.edit_text("\u26A0\ufe0F باید در کانال عضو باشی.", reply_markup=join_channel_keyboard())
            return
    if has_user_sent(user_id):
        await callback.message.edit_text("\u26A0\ufe0F شما در طول روز یک بار می‌توانید پیام ارسال کنید!", reply_markup=back_to_menu_keyboard())
        return
    topic = load_topic()
    await state.set_state(UserState.waiting_identified)
    await callback.message.edit_text(f"\U0001F4F0 موضوع امروز: {topic}\n\n\U0001F464 پیام با هویت\n\nپیام متنی خودتون رو ارسال کنید\nاین پیام با یوزرنیم شما فوروارد می‌شه\U0001F604\n\n\U0001F6E1\ufe0F توجه : پیام خودتون رو به صورت کامل و بدون کات یک جا بفرستید .\U0001FAE0\U0001F64F\n\n\u26A0\ufe0F برای انصراف دکمه پایین رو بزن.", reply_markup=back_to_menu_keyboard())

@dp.message(UserState.waiting_anonymous)
async def receive_anonymous(message: Message, state: FSMContext):
    if not message.text:
        return
    user_id = message.from_user.id
    add_user_to_sent(user_id)
    admin_id = int(ADMIN_ID)
    await bot.send_message(chat_id=admin_id, text="\U0001F4E9 پیام ناشناس جدید")
    await bot.send_chat_action(chat_id=admin_id, action=ChatAction.TYPING)
    await asyncio.sleep(1.5)
    await bot.send_message(chat_id=admin_id, text=message.text)
    await message.answer("\u2705 پیام ناشناس تو با موفقیت ارسال شد!", reply_markup=main_menu_keyboard())
    await state.clear()

@dp.message(UserState.waiting_identified)
async def receive_identified(message: Message, state: FSMContext):
    if not message.text:
        return
    user_id = message.from_user.id
    add_user_to_sent(user_id)
    user = message.from_user
    username = user.username
    full_name = user.full_name or "کاربر"
    signature = f"@{username}" if username else full_name
    admin_id = int(ADMIN_ID)
    combined_text = f"{message.text}\n\n\u2014 {signature}"
    await bot.send_message(chat_id=admin_id, text=combined_text)
    await message.answer("\u2705 پیام شما با موفقیت ارسال شد!", reply_markup=main_menu_keyboard())
    await state.clear()

@dp.callback_query(F.data == "rules")
async def show_rules(callback: CallbackQuery):
    rules_text = "\U0001F4DC قوانین ارسال متن\n\nپیام شما پس از ارسال به دست ادمین کانال می‌رسد\nلذا موارد زیر اگر رعایت نشود پیام شما فوروارد نخواهد شد!\n\n1\ufe0f\u20e3 بی‌ادبی و توهین\n2\ufe0f\u20e3 سیاسی\n3\ufe0f\u20e3 نداشتن ارتباط با موضوع روز کانال\n4\ufe0f\u20e3 داشتن لینک و یا موارد تبلیغاتی\n5\ufe0f\u20e3 اسپم و فلود"
    await callback.message.edit_text(rules_text, reply_markup=back_to_menu_keyboard())

@dp.callback_query(F.data == "back_menu")
async def back_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    if str(user_id) == ADMIN_ID:
        await callback.message.edit_text("از منوی زیر یکی رو انتخاب کن:", reply_markup=main_menu_with_admin_keyboard())
    else:
        await callback.message.edit_text("از منوی زیر یکی رو انتخاب کن:", reply_markup=main_menu_keyboard())

@dp.channel_post()
async def channel_post_handler(message: Message):
    text = message.text or ""
    logging.info(f"پیام کانال دریافت شد: {text}")
    if text.startswith("*"):
        topic = text.replace("*", "").strip()
        if topic:
            save_topic(topic)
            clear_sent_users()
            admin_id = int(ADMIN_ID)
            await bot.send_message(chat_id=admin_id, text=f"\u2705 موضوع روز بروزرسانی شد:\n\n\U0001F4F0 {topic}\n\n\U0001F5D1\ufe0F لیست کاربران پاک شد.")

async def main():
    # اجرای Flask در thread جدا برای بیدار نگه داشتن ربات
    flask_thread = Thread(target=run_flask)
    flask_thread.daemon = True
    flask_thread.start()
    logging.info("Web server started on port 5000")

    logging.info("Bot is starting...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())